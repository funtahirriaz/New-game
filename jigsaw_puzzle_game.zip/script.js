const imageSrc = "https://source.unsplash.com/300x300/?nature"; // Replace with your image URL
const board = document.getElementById("board");
const pieces = document.getElementById("pieces");

let positions = [];
let shuffledPositions = [];

function createPuzzle() {
    for (let row = 0; row < 3; row++) {
        for (let col = 0; col < 3; col++) {
            let piece = document.createElement("div");
            piece.classList.add("piece");
            piece.style.backgroundImage = `url('${imageSrc}')`;
            piece.style.backgroundPosition = `-${col * 100}px -${row * 100}px`;
            positions.push({ row, col, piece });
            pieces.appendChild(piece);
        }
    }
    shufflePieces();
}

function shufflePieces() {
    shuffledPositions = [...positions].sort(() => Math.random() - 0.5);
    pieces.innerHTML = "";
    shuffledPositions.forEach(({ piece }) => pieces.appendChild(piece));
}

document.addEventListener("dragstart", (e) => {
    e.dataTransfer.setData("text", positions.indexOf(shuffledPositions.find(p => p.piece === e.target)));
});

document.addEventListener("dragover", (e) => {
    e.preventDefault();
});

document.addEventListener("drop", (e) => {
    e.preventDefault();
    let fromIndex = e.dataTransfer.getData("text");
    let toPiece = e.target;
    let toIndex = shuffledPositions.findIndex(p => p.piece === toPiece);

    if (toIndex !== -1) {
        let temp = shuffledPositions[toIndex];
        shuffledPositions[toIndex] = shuffledPositions[fromIndex];
        shuffledPositions[fromIndex] = temp;

        pieces.innerHTML = "";
        shuffledPositions.forEach(({ piece }) => pieces.appendChild(piece));

        checkWin();
    }
});

function checkWin() {
    if (JSON.stringify(shuffledPositions) === JSON.stringify(positions)) {
        document.getElementById("message").textContent = "Congratulations! You solved the puzzle!";
    }
}

createPuzzle();
